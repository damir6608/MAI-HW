import { describe, expect, it } from 'vitest';
import { earliestDelivery, totals, updateCart, validateDelivery } from '../src/domain/order';
import { validateCatalog } from '../src/data/api';
import catalog from '../public/catalog.json';

const product = catalog[0];
describe('расчёт заказа в копейках', () => {
  it('день, две порции, доставка один раз', () => {
    expect(totals([{ ...product, quantity: 2 }], 1)).toEqual({ subtotal: 180000, delivery: 15000, total: 195000 });
  });
  it('неделя и несколько разных позиций', () => {
    expect(totals([{ ...product, quantity: 2 }, { ...catalog[1], quantity: 1 }], 7).total).toBe(1870000);
  });
  it('пустой заказ без доставки', () => { expect(totals([], 7)).toEqual({ subtotal: 0, delivery: 0, total: 0 }); });
  it.each([0, 2, true, '7'])('отклоняет период %s', days => { expect(() => totals([], days)).toThrow(RangeError); });
  it.each([-1, 0.5, true, Number.MAX_SAFE_INTEGER])('отклоняет цену или переполнение %s', priceKopecks => {
    expect(() => totals([{ ...product, priceKopecks, quantity: 2 }], 7)).toThrow(RangeError);
  });
  it.each([0, 10, 1.5, false])('отклоняет количество %s', quantity => {
    expect(() => totals([{ ...product, quantity }], 1)).toThrow(RangeError);
  });
});
describe('изменение корзины', () => {
  it('не мутирует исходный массив и позицию', () => {
    const cart = Object.freeze([Object.freeze({ ...product, quantity: 1 })]);
    const result = updateCart(cart, product, 1);
    expect(result[0].quantity).toBe(2); expect(cart[0].quantity).toBe(1);
  });
  it('добавляет новую позицию', () => { expect(updateCart([], product, 1)[0].quantity).toBe(1); });
  it('удаляет при уменьшении до нуля', () => { expect(updateCart([{ ...product, quantity: 1 }], product, -1)).toEqual([]); });
  it('ограничивает девятью', () => { expect(updateCart([{ ...product, quantity: 9 }], product, 1)[0].quantity).toBe(9); });
});
describe('дата доставки', () => {
  const today = new Date(2026, 11, 30, 23, 59);
  it('плюс два календарных дня через смену года', () => { expect(earliestDelivery(today)).toBe('2027-01-01'); });
  it('допускает граничную дату', () => { expect(validateDelivery('2027-01-01', today)).toBe(''); });
  it('отклоняет раннюю дату', () => { expect(validateDelivery('2026-12-31', today)).toMatch(/через 2 дня/); });
  it('отклоняет несуществующий день', () => { expect(validateDelivery('2027-02-30', today)).toMatch(/корректную/); });
  it('отклоняет пустое поле', () => { expect(validateDelivery('', today)).toMatch(/Выберите/); });
});
describe('граница mock API', () => {
  it('принимает валидный каталог и пустой результат', () => { expect(validateCatalog(catalog)).toHaveLength(4); expect(validateCatalog([])).toEqual([]); });
  it('отклоняет дубли ID', () => { expect(() => validateCatalog([product, product])).toThrow(); });
  it('отклоняет дробную цену', () => { expect(() => validateCatalog([{ ...product, priceKopecks: 1.2 }])).toThrow(); });
  it('отклоняет неправильные поля меню', () => { expect(() => validateCatalog([{ ...product, meals: [null] }])).toThrow(); });
});
