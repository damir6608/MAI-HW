import { fireEvent, render, screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { describe, expect, it, vi } from 'vitest';
import App from '../src/App';
import Checkout from '../src/components/Checkout';
import Cart from '../src/components/Cart';
import { earliestDelivery } from '../src/domain/order';
import catalog from '../public/catalog.json';

const cart = [{ ...catalog[0], quantity: 1 }];
const mockApi = () => ({ loadCatalog: vi.fn().mockResolvedValue(catalog), submitDemoOrder: vi.fn().mockResolvedValue({ number: 'FT-TEST' }) });
const checkout = api => render(<Checkout cart={cart} days={1} onChange={vi.fn()} onSuccess={vi.fn()} api={api} />);
const setDate = () => fireEvent.change(screen.getByLabelText('Дата первой доставки'), { target: { value: earliestDelivery() } });

describe('каталог и фильтр', () => {
  it('показывает загрузку до получения данных', () => {
    const api = { loadCatalog: () => new Promise(() => {}) }; render(<App api={api} />);
    expect(screen.getByText('Загружаем рационы…')).toBeInTheDocument();
  });
  it('показывает четыре карточки и фильтрует по типу', async () => {
    const user = userEvent.setup(); render(<App api={mockApi()} />);
    await screen.findByTestId('product-balance');
    expect(screen.getAllByRole('button', { name: /^Добавить / })).toHaveLength(4);
    await user.click(screen.getByRole('button', { name: 'Растительные', exact: true }));
    expect(screen.getAllByRole('button', { name: /^Добавить / })).toHaveLength(1);
    expect(screen.getByRole('heading', { name: 'Больше растений' })).toBeInTheDocument();
  });
  it('повторяет запрос после ошибки и восстанавливает каталог', async () => {
    const api = mockApi(); api.loadCatalog.mockRejectedValueOnce(new Error('offline'));
    const user = userEvent.setup(); render(<App api={api} />);
    expect(await screen.findByRole('alert')).toHaveTextContent('Проверьте подключение');
    await user.click(screen.getByRole('button', { name: 'Повторить загрузку' }));
    expect(await screen.findByTestId('product-balance')).toBeInTheDocument(); expect(api.loadCatalog).toHaveBeenCalledTimes(2);
  });
  it('показывает пустой каталог', async () => {
    const api = mockApi(); api.loadCatalog.mockResolvedValue([]); render(<App api={api} />);
    expect(await screen.findByText('Пока нет доступных рационов')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'К оформлению' })).toBeDisabled();
  });
  it('позволяет сбросить фильтр без результатов', async () => {
    const api = mockApi(); api.loadCatalog.mockResolvedValue([catalog[0]]); const user = userEvent.setup(); render(<App api={api} />);
    await screen.findByTestId('product-balance'); await user.click(screen.getByRole('button', { name: 'Растительные' }));
    expect(screen.getByText('Нет рационов по этому фильтру')).toBeInTheDocument();
    await user.click(screen.getAllByRole('button', { name: 'Все рационы', exact: true })[1]);
    expect(screen.getByTestId('product-balance')).toBeInTheDocument();
  });
});
describe('меню и корзина', () => {
  it('открывает доступный диалог с аллергенами и закрывает кнопкой', async () => {
    const user = userEvent.setup(); render(<App api={mockApi()} />); await screen.findByTestId('product-balance');
    await user.click(screen.getByRole('button', { name: 'Смотреть меню Баланс на каждый день' }));
    const dialog = screen.getByRole('dialog', { name: 'Баланс на каждый день' }); expect(within(dialog).getByText('Аллергены:')).toBeInTheDocument();
    await user.click(within(dialog).getByRole('button', { name: 'Закрыть меню' })); expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Смотреть меню Баланс на каждый день' })).toHaveFocus();
  });
  it('пересчитывает день/неделю и удаляет позицию через минус', async () => {
    const user = userEvent.setup(); render(<App api={mockApi()} />); await screen.findByTestId('product-balance');
    await user.click(screen.getByRole('button', { name: 'Добавить Баланс на каждый день' }));
    expect(screen.getByTestId('cart-total')).toHaveTextContent(/1\s050\s₽/);
    await user.click(screen.getByRole('button', { name: '7 дней', exact: true }));
    expect(screen.getByTestId('cart-total')).toHaveTextContent(/6\s450\s₽/);
    await user.click(screen.getByRole('button', { name: 'Уменьшить Баланс на каждый день' }));
    expect(screen.getByTestId('cart-total')).toHaveTextContent(/0\s₽/); expect(screen.getByRole('button', { name: 'К оформлению' })).toBeDisabled();
  });
  it('блокирует увеличение при девяти', () => {
    render(<Cart cart={[{ ...catalog[0], quantity: 9 }]} days={1} onChange={vi.fn()} onCheckout={vi.fn()} />);
    expect(screen.getByRole('button', { name: 'Увеличить Баланс на каждый день' })).toBeDisabled();
  });
});
describe('оформление', () => {
  it('пустая корзина не показывает форму', () => {
    render(<Checkout cart={[]} days={1} api={mockApi()} />); expect(screen.getByText('Ваша корзина пуста')).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: 'Подтвердить демозаказ' })).not.toBeInTheDocument();
  });
  it('пустая дата блокирует API и сохраняет заказ', async () => {
    const api = mockApi(); checkout(api); await userEvent.click(screen.getByRole('button', { name: 'Подтвердить демозаказ' }));
    expect(screen.getByRole('alert')).toHaveTextContent('Выберите дату'); expect(api.submitDemoOrder).not.toHaveBeenCalled(); expect(screen.getByTestId('cart-total')).toHaveTextContent(/1\s050/);
  });
  it('ранняя дата блокирует API', async () => {
    const api = mockApi(); checkout(api); fireEvent.change(screen.getByLabelText('Дата первой доставки'), { target: { value: '2020-01-01' } });
    await userEvent.click(screen.getByRole('button', { name: 'Подтвердить демозаказ' })); expect(screen.getByRole('alert')).toHaveTextContent('через 2 дня'); expect(api.submitDemoOrder).not.toHaveBeenCalled();
  });
  it('требует согласие с демонстрационным режимом', async () => {
    const api = mockApi(); checkout(api); setDate(); await userEvent.click(screen.getByRole('button', { name: 'Подтвердить демозаказ' }));
    expect(screen.getByRole('alert')).toHaveTextContent('демонстрационный режим'); expect(api.submitDemoOrder).not.toHaveBeenCalled();
  });
  it('отправляет корректный снимок заказа и блокирует двойную отправку', async () => {
    let resolve; const api = mockApi(); api.submitDemoOrder.mockImplementation(() => new Promise(done => { resolve = done; }));
    const onSuccess = vi.fn(); render(<Checkout cart={cart} days={7} onChange={vi.fn()} onSuccess={onSuccess} api={api} />);
    setDate(); await userEvent.click(screen.getByRole('checkbox')); const button = screen.getByRole('button', { name: 'Подтвердить демозаказ' });
    fireEvent.click(button); fireEvent.click(button); expect(api.submitDemoOrder).toHaveBeenCalledTimes(1); expect(button).toBeDisabled();
    expect(api.submitDemoOrder).toHaveBeenCalledWith(expect.objectContaining({ total: 645000, days: 7, date: earliestDelivery() }));
    resolve({ number: 'FT-TEST' }); await waitFor(() => expect(onSuccess).toHaveBeenCalledWith({ number: 'FT-TEST' }));
  });
  it.each([undefined, 401])('сбой API %s сохраняет форму и корзину', async status => {
    const api = mockApi(); api.submitDemoOrder.mockRejectedValue(Object.assign(new Error('unavailable'), { status })); checkout(api); setDate();
    await userEvent.click(screen.getByRole('checkbox')); await userEvent.click(screen.getByRole('button', { name: 'Подтвердить демозаказ' }));
    expect(await screen.findByRole('alert')).toHaveTextContent(status === 401 ? 'Личный кабинет недоступен' : 'Не удалось оформить');
    expect(screen.getByLabelText('Дата первой доставки')).toHaveValue(earliestDelivery()); expect(screen.getByTestId('cart-total')).toHaveTextContent(/1\s050/);
    expect(screen.getByRole('button', { name: 'Подтвердить демозаказ' })).toBeEnabled();
  });
  it('успех очищает корзину и показывает подтверждение', async () => {
    const api = mockApi(); api.submitDemoOrder.mockImplementation(async order => ({ ...order, number: 'FT-TEST' })); const user = userEvent.setup(); render(<App api={api} />);
    await screen.findByTestId('product-balance'); await user.click(screen.getByRole('button', { name: 'Добавить Баланс на каждый день' }));
    await user.click(screen.getByRole('button', { name: 'К оформлению' })); await screen.findByText('Когда вам удобно?'); setDate();
    await user.click(screen.getByRole('checkbox')); await user.click(screen.getByRole('button', { name: 'Подтвердить демозаказ' }));
    expect(await screen.findByRole('heading', { name: 'Демозаказ оформлен' })).toBeInTheDocument(); expect(screen.getByText('FT-TEST')).toBeInTheDocument();
    expect(screen.getByRole('link', { name: 'Корзина 0' })).toBeInTheDocument();
  });
});
