import { readdir, readFile } from 'node:fs/promises';
import { gzipSync } from 'node:zlib';
import assert from 'node:assert/strict';
const assets = (await readdir(new URL('../dist/assets/', import.meta.url))).filter(name => /\.(js|css)$/.test(name));
let bytes = 0;
for (const name of assets) bytes += gzipSync(await readFile(new URL(`../dist/assets/${name}`, import.meta.url))).length;
assert(assets.length >= 2, 'Missing production assets');
assert(bytes <= 350000, 'Production JS+CSS exceeds 350 kB gzip');
console.log(JSON.stringify({ assets, gzipBytes: bytes, limitBytes: 350000, passed: true }, null, 2));
