import { useEffect, useState } from 'react';
import * as defaultApi from './data/api';
import { money, updateCart } from './domain/order';
import ProductCard from './components/ProductCard';
import Plate from './components/Plate';
import Cart from './components/Cart';
import MenuDialog from './components/MenuDialog';
import Checkout from './components/Checkout';

const filters = [['all', 'Все рационы'], ['balance', 'Сбалансированные'], ['light', 'Лёгкие'], ['plant', 'Растительные']];

function useRoute() {
  const read = () => window.location.hash.startsWith('#/') ? window.location.hash.slice(1) : '/catalog';
  const [route, setRoute] = useState(read);
  useEffect(() => { const update = () => { setRoute(read()); if (window.location.hash.startsWith('#/')) window.scrollTo(0, 0); };
    window.addEventListener('hashchange', update); return () => window.removeEventListener('hashchange', update);
  }, []);
  return route;
}

export default function App({ api = defaultApi }) {
  const [catalog, setCatalog] = useState([]);
  const [status, setStatus] = useState('loading');
  const [retry, setRetry] = useState(0);
  const [filter, setFilter] = useState('all');
  const [days, setDays] = useState(1);
  const [cart, setCart] = useState([]);
  const [selected, setSelected] = useState(null);
  const [notice, setNotice] = useState('');
  const [order, setOrder] = useState(null);
  const route = useRoute();
  useEffect(() => {
    const controller = new AbortController(); setStatus('loading');
    api.loadCatalog({ signal: controller.signal }).then(data => {
      if (!controller.signal.aborted) { setCatalog(data); setStatus('success'); }
    }).catch(error => { if (!controller.signal.aborted) {
      console.warn('[FoodTech] catalog load failed', error.name); setStatus('error');
    } });
    return () => controller.abort();
  }, [api, retry]);
  useEffect(() => { if (!notice) return; const timer = setTimeout(() => setNotice(''), 2600); return () => clearTimeout(timer); }, [notice]);

  function changeCart(product, delta) { setCart(current => updateCart(current, product, delta)); }
  function add(product) { changeCart(product, 1); setNotice(`${product.name} — в корзине`); }
  function checkout() { window.location.hash = '/checkout'; }
  function success(result) { setOrder(result); setCart([]); window.location.hash = '/success'; }
  const visible = catalog.filter(product => filter === 'all' || product.type === filter);
  const count = cart.reduce((sum, item) => sum + item.quantity, 0);

  return <><a className="skip-link" href="#main-content">К содержимому</a>
    <header className="site-header"><a href="#/catalog" className="brand" aria-label="FoodTech — каталог"><span className="brand-symbol" aria-hidden="true">✳</span>foodtech<span className="brand-dot">.</span></a>
      <nav aria-label="Основная навигация"><a href="#/catalog" className={route === '/catalog' ? 'active' : ''}>Меню рационов</a><a href="#/account">Личный кабинет</a></nav>
      <a className="header-cart" href={route === '/catalog' ? '#cart' : '#/catalog'}>Корзина <span>{count}</span></a></header>
    <main id="main-content" className="page-shell">
      {route === '/checkout' ? <Checkout cart={cart} days={days} onChange={changeCart} onSuccess={success} api={api} />
        : route === '/success' && order ? <section className="state-screen success-screen"><span className="success-icon" aria-hidden="true">✓</span><p className="eyebrow">ВСЁ ГОТОВО</p><h1>Демозаказ оформлен</h1><p className="lead">Ваше меню уже в планах.</p>
          <dl className="confirmation"><div><dt>Номер</dt><dd>{order.number}</dd></div><div><dt>Первая доставка</dt><dd>{order.date}</dd></div><div><dt>Интервал</dt><dd>{order.slot}</dd></div><div><dt>Период</dt><dd>{order.days === 1 ? '1 день' : '7 дней'}</dd></div><div><dt>Итого</dt><dd>{money(order.total)}</dd></div></dl>
          <p>Это учебное подтверждение. Оплата не списывалась,<br />реальная доставка не оформлена.</p><a className="button primary" href="#/catalog">Вернуться к меню</a></section>
        : route === '/account' ? <section className="state-screen"><p className="eyebrow">ГОСТЕВОЙ РЕЖИМ</p><h1>Личный кабинет недоступен в демоверсии</h1><p>Вы можете изучить меню и оформить демонстрационный заказ без регистрации.</p><a className="button primary" href="#/catalog">Вернуться к меню</a></section>
        : route !== '/catalog' && route !== 'cart' ? <section className="state-screen"><h1>Эта страница не найдена</h1><a href="#/catalog" className="button primary">Вернуться к меню</a></section>
        : <><section className="hero"><div><p className="eyebrow">ГОТОВОЕ ПИТАНИЕ · ВАШ РИТМ</p><h1>Хорошая еда.<br /><em>Больше времени</em><br />на себя.</h1><p className="hero-copy">Выберите готовый рацион на день или неделю.<br className="desktop-break" /> Всё приготовлено — остаётся наслаждаться.</p><div className="hero-facts"><span>✓ Готовые наборы</span><span>✓ Понятный состав</span><span>✓ Без подписки</span></div></div>
          <div className="hero-visual"><div className="orbit-label">СВЕЖИЙ ВЗГЛЯД<br />НА КАЖДЫЙ ДЕНЬ</div><Plate large /><span className="hero-caption">Вы выбираете.<br /><strong>Мы уже приготовили.</strong></span></div></section>
          <section className="catalog-layout"><div className="catalog-main"><div className="catalog-title"><div><p className="eyebrow">МЕНЮ НА ВАШ ВКУС</p><h2>Найдите свой баланс</h2></div>
            <div className="duration" role="group" aria-label="Период заказа">{[1, 7].map(value => <button key={value} aria-pressed={days === value} onClick={() => setDays(value)}>{value === 1 ? '1 день' : '7 дней'}</button>)}</div></div>
            <div className="filter-row" role="group" aria-label="Тип питания">{filters.map(([key, label]) => <button key={key} aria-pressed={filter === key} onClick={() => setFilter(key)}>{label}</button>)}</div>
            {status === 'loading' ? <div className="catalog-state" role="status">Загружаем рационы…</div>
              : status === 'error' ? <div className="catalog-state"><h3>Не удалось загрузить меню</h3><p role="alert">Проверьте подключение и попробуйте ещё раз.</p><button className="primary" onClick={() => setRetry(value => value + 1)}>Повторить загрузку</button></div>
                : !visible.length ? <div className="catalog-state"><h3>{catalog.length ? 'Нет рационов по этому фильтру' : 'Пока нет доступных рационов'}</h3><p>Загляните позже или посмотрите другие варианты.</p><button onClick={() => setFilter('all')}>Все рационы</button></div>
                  : <div className="product-grid">{visible.map(product => <ProductCard key={product.id} product={product} onAdd={add} onDetails={setSelected} />)}</div>}
          </div><Cart cart={cart} days={days} onChange={changeCart} onCheckout={checkout} /></section>
          <section className="how-it-works"><p className="eyebrow">ПРОСТО ВСТРОИТЬ В СВОЙ ДЕНЬ</p><div><h2>Меньше забот.<br />Больше вкуса.</h2><ol><li><span>01</span><strong>Выберите рацион</strong><p>Состав и блюда уже перед вами.</p></li><li><span>02</span><strong>Определите период</strong><p>Попробуйте день или планируйте неделю.</p></li><li><span>03</span><strong>Выберите доставку</strong><p>Удобная дата и понятная сумма.</p></li></ol></div></section></>}
    </main><footer className="site-footer"><a href="#/catalog" className="brand">foodtech.</a><span>Демонстрационный проект · без реальных платежей</span><span>Готовое питание в вашем ритме</span></footer>
    {selected && <MenuDialog product={selected} onClose={() => setSelected(null)} onAdd={add} />}
    <div className={`toast ${notice ? 'visible' : ''}`} role="status" aria-live="polite">{notice}</div>
  </>;
}
