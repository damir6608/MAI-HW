export const DELIVERY_FEE = 15000;
export const MAX_QUANTITY = 9;

export function money(kopecks) {
  return new Intl.NumberFormat('ru-RU', {
    style: 'currency', currency: 'RUB', maximumFractionDigits: 0,
  }).format(kopecks / 100);
}

export function isoDate(date = new Date()) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}

export function earliestDelivery(today = new Date()) {
  const date = new Date(today.getFullYear(), today.getMonth(), today.getDate());
  date.setDate(date.getDate() + 2);
  return isoDate(date);
}

export function validateDelivery(value, today = new Date()) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return 'Выберите дату первой доставки.';
  const [year, month, day] = value.split('-').map(Number);
  const date = new Date(year, month - 1, day);
  if (isoDate(date) !== value) return 'Укажите корректную дату.';
  if (value < earliestDelivery(today)) return 'Первая доставка доступна не ранее чем через 2 дня.';
  return '';
}

export function totals(items, days) {
  if (![1, 7].includes(days)) throw new RangeError('days must be 1 or 7');
  for (const item of items) {
    if (!Number.isSafeInteger(item.priceKopecks) || item.priceKopecks < 0) {
      throw new RangeError('price must be a non-negative integer');
    }
    if (!Number.isInteger(item.quantity) || item.quantity < 1 || item.quantity > MAX_QUANTITY) {
      throw new RangeError('quantity must be from 1 to 9');
    }
  }
  const subtotal = items.reduce((sum, item) => sum + item.priceKopecks * item.quantity * days, 0);
  const delivery = items.length ? DELIVERY_FEE : 0;
  if (!Number.isSafeInteger(subtotal + delivery)) throw new RangeError('total is too large');
  return { subtotal, delivery, total: subtotal + delivery };
}

export function updateCart(cart, product, delta) {
  const existing = cart.find(item => item.id === product.id);
  const quantity = Math.min(MAX_QUANTITY, (existing?.quantity ?? 0) + delta);
  if (quantity <= 0) return cart.filter(item => item.id !== product.id);
  if (!existing) return [...cart, { ...product, quantity }];
  return cart.map(item => item.id === product.id ? { ...item, quantity } : item);
}
