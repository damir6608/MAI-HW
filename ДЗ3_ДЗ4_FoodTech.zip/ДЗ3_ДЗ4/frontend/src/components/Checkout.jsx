import { useRef, useState } from 'react';
import Cart from './Cart';
import { earliestDelivery, totals, validateDelivery } from '../domain/order';

export default function Checkout({ cart, days, onChange, onSuccess, api }) {
  const [date, setDate] = useState('');
  const [slot, setSlot] = useState('09:00–13:00');
  const [consent, setConsent] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const submitting = useRef(false);

  async function submit(event) {
    event.preventDefault();
    if (submitting.current) return;
    const dateError = validateDelivery(date);
    if (dateError || !consent) {
      setError(dateError || 'Подтвердите, что понимаете демонстрационный режим.');
      return;
    }
    submitting.current = true;
    setLoading(true); setError('');
    try {
      const result = await api.submitDemoOrder({
        items: cart.map(item => ({ id: item.id, quantity: item.quantity })),
        date, slot, days, ...totals(cart, days),
      });
      onSuccess(result);
    } catch (cause) {
      console.warn('[FoodTech] demo submit failed', cause.status === 401 ? '401' : 'unavailable');
      setError(cause.status === 401 ? 'Личный кабинет недоступен в демоверсии. Вернитесь к каталогу.'
        : 'Не удалось оформить демозаказ. Повторите попытку.');
    } finally { submitting.current = false; setLoading(false); }
  }

  if (!cart.length) return <section className="state-screen"><h1>Ваша корзина пуста</h1><p>Сначала выберите готовый рацион.</p><a className="button primary" href="#/catalog">Выбрать рацион</a></section>;

  return <section className="checkout-layout">
    <div><a className="back-link" href="#/catalog">← Вернуться к меню</a><p className="eyebrow">ПОСЛЕДНИЙ ШАГ</p><h1>Когда вам удобно?</h1>
      <p className="lead">Выберите первую доставку и проверьте ваш заказ.</p>
      <form noValidate onSubmit={submit} className="checkout-form" aria-describedby="checkout-disclaimer">
        <h2>Доставка</h2><p className="location">⌖ Москва — демонстрационная зона</p>
        <label htmlFor="delivery-date">Дата первой доставки</label>
        <input id="delivery-date" type="date" value={date} min={earliestDelivery()} required
          onChange={event => setDate(event.target.value)} aria-describedby="date-hint" />
        <small id="date-hint">Не раньше чем через 2 дня. На неделю доставляются рационы на 7 дней.</small>
        <label htmlFor="delivery-slot">Интервал доставки</label><select id="delivery-slot" value={slot} onChange={event => setSlot(event.target.value)}>
          <option>09:00–13:00</option><option>14:00–18:00</option></select>
        <div className="demo-notice" id="checkout-disclaimer"><strong>Это демонстрационный заказ</strong>
          <p>Оплата не списывается. Мы не запрашиваем адрес и платёжные данные.</p></div>
        <label className="check-label"><input type="checkbox" checked={consent} onChange={event => setConsent(event.target.checked)} />Я понимаю, что оформляю демозаказ</label>
        {error && <p role="alert" className="error-message">{error}</p>}
        <button className="primary full-width" type="submit" disabled={loading} aria-busy={loading}>{loading ? 'Подтверждаем…' : 'Подтвердить демозаказ'} <span aria-hidden="true">→</span></button>
      </form></div>
    <Cart cart={cart} days={days} onChange={onChange} compact />
  </section>;
}
