export default function Plate({ variant = 'balance', large = false }) {
  const primary = variant === 'plant' ? '#dca552' : variant === 'light' ? '#e6bc73' : '#c9875c';
  return <svg className={`plate ${large ? 'plate-large' : ''}`} viewBox="0 0 320 240" aria-hidden="true">
    <ellipse cx="160" cy="143" rx="126" ry="80" fill="#173f2e" opacity=".08" />
    <ellipse cx="160" cy="124" rx="122" ry="92" fill="#fffdf7" stroke="#dddcd0" strokeWidth="3" />
    <ellipse cx="160" cy="124" rx="99" ry="74" fill="#f3eee1" />
    <path d="M79 110c5-35 32-50 63-44l14 53-45 43c-23-5-36-23-32-52" fill="#74a36a" />
    {[0, 1, 2, 3, 4].map(i => <ellipse key={i} cx={98 + i * 12} cy={98 + (i % 2) * 23}
      rx="16" ry="11" transform={`rotate(${i * 26} 120 110)`} fill={i % 2 ? '#3f7646' : '#88b478'} />)}
    <path d="M155 68c37-5 68 14 79 41l-57 26-23-26z" fill={primary} />
    <path d="m176 80 13 36m5-34 13 29m3-20 10 14" stroke="#ae6844" strokeWidth="5" strokeLinecap="round" />
    <path d="M126 145c27-20 72-13 98-5-11 34-68 56-98 24z" fill="#e7cc8d" />
    {[0, 1, 2, 3, 4, 5, 6, 7].map(i => <ellipse key={i} cx={137 + i * 9} cy={151 + (i % 3) * 8}
      rx="4" ry="2" fill="#be9d62" transform={`rotate(-25 ${137 + i * 9} 154)`} />)}
    <circle cx="104" cy="145" r="13" fill="#db654d" /><circle cx="119" cy="134" r="11" fill="#e27d5b" />
    <path d="m109 141-1 8m-4-4h8" stroke="#f9c49a" strokeWidth="2" />
    <path d="m153 121 11-15 7 14-11 9z" fill="#477d49" />
  </svg>;
}
