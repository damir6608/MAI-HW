import { MAX_QUANTITY, money, totals } from '../domain/order';

export default function Cart({ cart, days, onChange, onCheckout, compact = false }) {
  const summary = totals(cart, days);
  return <section className={`cart-panel ${compact ? 'cart-compact' : ''}`} aria-labelledby="cart-title" id="cart">
    <div className="section-heading"><h2 id="cart-title">Ваш заказ</h2><span className="count-badge">{cart.reduce((sum, item) => sum + item.quantity, 0)}</span></div>
    <p className="muted">{days === 1 ? 'На один день' : 'На семь дней'} · готовые рационы</p>
    {!cart.length ? <div className="empty-cart"><span aria-hidden="true">⌑</span><h3>Здесь будет ваш рацион</h3>
      <p>Выберите готовый набор из меню — мы посчитаем всё остальное.</p></div>
      : <ul className="cart-items">{cart.map(item => <li key={item.id}>
        <div className="cart-item-heading"><strong>{item.name}</strong><button className="icon-button" aria-label={`Удалить ${item.name}`} onClick={() => onChange(item, -item.quantity)}>×</button></div>
        <div className="cart-item-bottom"><div className="quantity"><button aria-label={`Уменьшить ${item.name}`} onClick={() => onChange(item, -1)}>−</button>
          <output aria-label={`Количество ${item.name}`}>{item.quantity}</output>
          <button disabled={item.quantity >= MAX_QUANTITY} aria-label={`Увеличить ${item.name}`} onClick={() => onChange(item, 1)}>+</button></div>
          <span>{money(item.priceKopecks * item.quantity * days)}</span></div>
      </li>)}</ul>}
    <dl className="price-lines"><div><dt>Рационы</dt><dd>{money(summary.subtotal)}</dd></div>
      <div><dt>Доставка <span title="Один раз за весь заказ">↗</span></dt><dd>{cart.length ? money(summary.delivery) : '—'}</dd></div>
      <div className="total-line"><dt>Итого</dt><dd data-testid="cart-total">{money(summary.total)}</dd></div></dl>
    {!compact && <button className="primary full-width" disabled={!cart.length} onClick={onCheckout}>К оформлению <span aria-hidden="true">→</span></button>}
    <p className="cart-note">Первую доставку можно выбрать<br />не раньше чем через 2 дня.</p>
  </section>;
}
