import { useEffect, useRef } from 'react';
import { money } from '../domain/order';

export default function MenuDialog({ product, onClose, onAdd }) {
  const ref = useRef(null);
  const returnFocus = useRef(null);
  useEffect(() => {
    const dialog = ref.current;
    returnFocus.current ??= document.activeElement;
    if (!dialog.open) dialog.showModal();
    return () => { if (dialog.open) dialog.close(); returnFocus.current?.focus(); };
  }, []);
  return <dialog ref={ref} aria-labelledby="menu-title" onCancel={onClose}>
    <div className="dialog-head"><div><p className="eyebrow">ГОТОВОЕ МЕНЮ НА ДЕНЬ</p><h2 id="menu-title">{product.name}</h2></div>
      <button className="icon-button" aria-label="Закрыть меню" onClick={onClose}>×</button></div>
    <p>{product.calories} ккал · белки {product.protein} г · жиры {product.fat} г · углеводы {product.carbs} г</p>
    <ol className="meal-list">{product.meals.map((meal, index) => <li key={meal}><span>0{index + 1}</span>{meal}</li>)}</ol>
    <p><strong>Основные ингредиенты:</strong> {product.ingredients.join(', ')}.</p>
    <p><strong>Аллергены:</strong> {product.allergens.length ? product.allergens.join(', ') : 'не указаны'}.</p>
    <p className="muted">Пример учебного меню. Состав рациона не редактируется.</p>
    <button className="primary full-width" onClick={() => { onAdd(product); onClose(); }}>Добавить за {money(product.priceKopecks)} / день</button>
  </dialog>;
}
