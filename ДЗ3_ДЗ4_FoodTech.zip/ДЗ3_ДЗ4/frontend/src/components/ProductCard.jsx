import Plate from './Plate';
import { money } from '../domain/order';

export const typeLabels = { balance: 'Сбалансированный', light: 'Лёгкий', plant: 'Растительный' };
const dishForms = { one: 'блюдо', few: 'блюда', many: 'блюд', other: 'блюда' };
const plural = new Intl.PluralRules('ru');

export default function ProductCard({ product, onAdd, onDetails }) {
  return <article className="product-card" data-testid={`product-${product.id}`}>
    <div className={`product-art art-${product.type}`}>
      <span className="type-tag">{typeLabels[product.type]}</span>
      <Plate variant={product.type} />
      <span className="calories">{product.calories} ккал</span>
    </div>
    <div className="product-body">
      <h3>{product.name}</h3><p>{product.description}</p>
      <button className="text-button menu-link" onClick={() => onDetails(product)}
        aria-label={`Смотреть меню ${product.name}`}>{product.meals.length} {dishForms[plural.select(product.meals.length)]} · Смотреть меню <span>↗</span></button>
      <div className="card-bottom"><div><strong>{money(product.priceKopecks)}</strong><small>за день</small></div>
        <button className="add-button" onClick={() => onAdd(product)} aria-label={`Добавить ${product.name}`}>
          <span aria-hidden="true">＋</span> Добавить</button></div>
    </div>
  </article>;
}
