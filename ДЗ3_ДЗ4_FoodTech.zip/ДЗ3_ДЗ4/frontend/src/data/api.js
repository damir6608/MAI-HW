export function validateCatalog(data) {
  if (!Array.isArray(data)) throw new Error('catalog must be an array');
  const ids = new Set();
  for (const product of data) {
    if (!product || typeof product.id !== 'string' || ids.has(product.id)
      || typeof product.name !== 'string' || !['balance', 'light', 'plant'].includes(product.type)
      || !Number.isSafeInteger(product.priceKopecks) || product.priceKopecks < 0
      || !Number.isFinite(product.calories) || product.calories <= 0
      || !['protein', 'fat', 'carbs'].every(key => Number.isFinite(product[key]) && product[key] >= 0)
      || !['meals', 'ingredients', 'allergens'].every(key =>
        Array.isArray(product[key]) && product[key].every(value => typeof value === 'string'))
      || !product.meals.length || typeof product.description !== 'string') {
      throw new Error('invalid catalog item');
    }
    ids.add(product.id);
  }
  return data;
}

export async function loadCatalog({ signal } = {}) {
  const mode = new URLSearchParams(window.location.search).get('demo');
  if (mode === 'catalog-error') throw new Error('demo catalog unavailable');
  if (mode === 'empty') return [];
  const response = await fetch('/catalog.json', { signal });
  if (!response.ok) throw new Error(`catalog status ${response.status}`);
  return validateCatalog(await response.json());
}

export async function submitDemoOrder(order) {
  await new Promise(resolve => setTimeout(resolve, 450));
  const mode = new URLSearchParams(window.location.search).get('demo');
  if (mode === 'submit-error') throw new Error('demo submit unavailable');
  if (mode === 'unauthorized') {
    const error = new Error('unauthorized');
    error.status = 401;
    throw error;
  }
  return { ...order, number: `FT-${String(Date.now()).slice(-6)}` };
}
