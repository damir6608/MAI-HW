# FoodTech frontend

React, Vite, JavaScript ES modules, Pico CSS. Node.js 24.

```sh
npm ci --legacy-peer-deps
npm run dev
npm test
npm run build
npm run check:build
npm run preview
```

Сервер разработки: http://127.0.0.1:5173/, production preview:
http://127.0.0.1:4173/ (точный порт смотрите в выводе Vite).

Каталог, меню, корзина на 1/7 дней, форма доставки today+2 и подтверждение.
Реальных платежей, заказов, авторизации и персональных данных нет.
Цена хранится в копейках, доставка 15000 копеек один раз, количество 1–9.
Состояние в памяти вкладки; reload сбрасывает корзину и результат.

Проверка ошибок: `?demo=catalog-error`, `?demo=empty`,
`?demo=submit-error`, `?demo=unauthorized` перед hash маршрута.
Удалите query и перезагрузите страницу для обычного режима.

Компоненты: src/components. Доменные правила: src/domain/order.js.
Mock API и проверка входных данных: src/data/api.js.
Тесты: tests/order.test.js и tests/components.test.jsx.
Полные материалы ДЗ3/ДЗ4 — в GitHub-репозитории:
https://github.com/damir6608/foodtech-hw3-hw4
